import process from "node:process";

process.stderr.write("请完成合作方Webhook裁决与重放队列生成逻辑\n");
process.exitCode = 2;
