import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { createPublicKey, verify } from "node:crypto";

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`);
    return `{${entries.join(",")}}`;
  }
  return JSON.stringify(value);
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (quoted) throw new Error("CSV引号未闭合");
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  const headers = rows.shift() ?? [];
  if (headers.length === 0) throw new Error("CSV缺少表头");
  return rows
    .filter((values) => values.some((value) => value !== ""))
    .map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvText(headers, rows) {
  const body = rows.map((row) => headers.map((header) => csvCell(row[header])).join(","));
  return `${headers.join(",")}\n${body.join("\n")}\n`;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function readJsonLines(file) {
  return fs.readFileSync(file, "utf8")
    .split(/\r?\n/)
    .filter((line) => line.trim() !== "")
    .map((line, index) => {
      try {
        return JSON.parse(line);
      } catch {
        throw new Error(`JSONL第${index + 1}行无法解析`);
      }
    });
}

function canonicalMessage(event) {
  return `${event.provider}\n${event.delivery_id}\n${event.created_at_utc}\n${stableJson(event.body)}`;
}

function secondsBetween(left, right) {
  return Math.round((Date.parse(right) - Date.parse(left)) / 1000);
}

function addSeconds(timestamp, seconds) {
  return new Date(Date.parse(timestamp) + seconds * 1000).toISOString().replace(".000Z", "Z");
}

function getPath(object, dottedPath) {
  return dottedPath.split(".").reduce((value, part) => value?.[part], object);
}

function parseArgs(argv) {
  const result = { input: ".", output: "deliverables" };
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === "--input") result.input = argv[index + 1];
    if (argv[index] === "--output") result.output = argv[index + 1];
  }
  return result;
}

function build(inputRoot) {
  const contract = readJson(path.join(inputRoot, "rules", "intake_contract.json"));
  const outputContract = readJson(path.join(inputRoot, "rules", "output_contract.json"));
  const providerConfig = readJson(path.join(inputRoot, "security", "provider_keys.json"));
  const providers = new Map(
    Object.entries(providerConfig).map(([provider, config]) => [provider, createPublicKey(config.public_key_pem)]),
  );
  const endpoints = parseCsv(fs.readFileSync(path.join(inputRoot, "routing", "endpoint_policy.csv"), "utf8"))
    .map((row) => ({
      ...row,
      active: row.active === "true",
      max_attempts: Number(row.max_attempts),
      base_delay_seconds: Number(row.base_delay_seconds),
    }));
  const endpointByType = new Map(endpoints.map((row) => [row.event_type, row]));
  const ledger = parseCsv(fs.readFileSync(path.join(inputRoot, "history", "idempotency_ledger.csv"), "utf8"));
  const attempts = parseCsv(fs.readFileSync(path.join(inputRoot, "history", "attempt_history.csv"), "utf8"))
    .map((row) => ({ ...row, attempt_no: Number(row.attempt_no) }));
  const events = readJsonLines(path.join(inputRoot, "incoming", "webhook_events.jsonl"));

  const attemptsByEvent = new Map();
  for (const attempt of attempts) {
    const rows = attemptsByEvent.get(attempt.event_id) ?? [];
    rows.push(attempt);
    attemptsByEvent.set(attempt.event_id, rows);
  }
  for (const rows of attemptsByEvent.values()) {
    rows.sort((left, right) => left.attempt_no - right.attempt_no || left.attempted_at_utc.localeCompare(right.attempted_at_utc));
  }

  const decisions = [];
  const queue = [];
  const batchKeys = new Map();

  for (const event of events) {
    const endpoint = endpointByType.get(event.event_type);
    const providerKey = providers.get(event.provider);
    const priorAttempts = attemptsByEvent.get(event.event_id) ?? [];
    const duplicateKey = `${event.provider}\u0000${event.delivery_id}`;
    let result = null;

    for (const rule of contract.decision_order) {
      if (rule === "unknown_provider" && !providerKey) {
        result = { reason: rule, detail: "provider_missing" };
      } else if (rule === "invalid_signature") {
        let signatureOk = false;
        try {
          signatureOk = verify(null, Buffer.from(canonicalMessage(event), "utf8"), providerKey, Buffer.from(event.signature, "base64url"));
        } catch {
          signatureOk = false;
        }
        if (!signatureOk) result = { reason: rule, detail: "signature_mismatch" };
      } else if (rule === "timestamp_out_of_window") {
        const offset = Math.abs(secondsBetween(event.created_at_utc, event.received_at_utc));
        if (!Number.isFinite(offset) || offset > contract.received_window_seconds) {
          result = { reason: rule, detail: `offset_seconds=${offset}` };
        }
      } else if (rule === "duplicate_in_ledger") {
        const match = ledger.find((row) => {
          if (row.provider !== event.provider || row.delivery_id !== event.delivery_id) return false;
          const ageHours = secondsBetween(row.processed_at_utc, event.received_at_utc) / 3600;
          return ageHours >= 0 && ageHours <= contract.idempotency_window_hours;
        });
        if (match) result = { reason: rule, detail: `processed_at_utc=${match.processed_at_utc}` };
      } else if (rule === "duplicate_in_batch") {
        if (batchKeys.has(duplicateKey)) {
          result = { reason: rule, detail: `earlier_event_id=${batchKeys.get(duplicateKey)}` };
        } else {
          batchKeys.set(duplicateKey, event.event_id);
        }
      } else if (rule === "unsupported_event_type" && !endpoint) {
        result = { reason: rule, detail: "policy_missing" };
      } else if (rule === "endpoint_inactive" && endpoint && !endpoint.active) {
        result = { reason: rule, detail: `endpoint_id=${endpoint.endpoint_id}` };
      } else if (rule === "schema_missing_field" && endpoint) {
        const required = contract.required_body_fields[event.event_type] ?? [];
        const missing = required.filter((field) => getPath(event.body, field) === undefined);
        if (missing.length > 0) result = { reason: rule, detail: `missing=${missing.join("|")}` };
      } else if (rule === "max_attempts_exhausted" && endpoint && priorAttempts.length >= endpoint.max_attempts) {
        result = { reason: rule, detail: `prior_attempts=${priorAttempts.length};max_attempts=${endpoint.max_attempts}` };
      } else if (rule === "queue_replay" && endpoint) {
        const lastAttempt = priorAttempts.at(-1);
        const attemptNo = lastAttempt ? lastAttempt.attempt_no + 1 : 1;
        const scheduledAt = lastAttempt
          ? addSeconds(lastAttempt.attempted_at_utc, endpoint.base_delay_seconds * (2 ** (attemptNo - 1)))
          : event.received_at_utc;
        result = { reason: "ready_for_replay", detail: "ready", attemptNo, scheduledAt };
      }
      if (result) break;
    }
    if (!result) throw new Error(`事件${event.event_id}没有得到终态`);

    const queued = result.reason === "ready_for_replay";
    const decision = {
      event_id: event.event_id,
      provider: event.provider,
      delivery_id: event.delivery_id,
      event_type: event.event_type,
      decision: queued ? "queue" : "reject",
      reason: result.reason,
      endpoint_id: endpoint?.endpoint_id ?? "",
      next_attempt_no: queued ? result.attemptNo : "",
      scheduled_at_utc: queued ? result.scheduledAt : "",
      detail: result.detail,
    };
    decisions.push(decision);
    if (queued) {
      queue.push({
        event_id: event.event_id,
        provider: event.provider,
        delivery_id: event.delivery_id,
        event_type: event.event_type,
        endpoint_id: endpoint.endpoint_id,
        account_id: event.body.account_id,
        attempt_no: result.attemptNo,
        scheduled_at_utc: result.scheduledAt,
      });
    }
  }

  queue.sort((left, right) => left.scheduled_at_utc.localeCompare(right.scheduled_at_utc) || left.event_id.localeCompare(right.event_id));
  const handoff = endpoints.map((endpoint) => {
    const endpointQueue = queue.filter((row) => row.endpoint_id === endpoint.endpoint_id);
    const rejected = decisions.filter((row) => row.event_type === endpoint.event_type && row.decision === "reject");
    return {
      event_type: endpoint.event_type,
      endpoint_id: endpoint.endpoint_id,
      active: String(endpoint.active),
      queued_count: endpointQueue.length,
      rejected_count: rejected.length,
      earliest_scheduled_at_utc: endpointQueue[0]?.scheduled_at_utc ?? "",
      max_attempts: endpoint.max_attempts,
    };
  });

  return { decisions, queue, handoff, outputContract };
}

function publish(outputRoot, result) {
  const parent = path.dirname(outputRoot);
  fs.mkdirSync(parent, { recursive: true });
  const staging = path.join(parent, `.webhook-deliverables-${process.pid}-${Date.now()}`);
  fs.rmSync(staging, { recursive: true, force: true });
  fs.mkdirSync(staging, { recursive: true });
  try {
    const decisionHeaders = result.outputContract["intake_decisions.csv"].columns;
    const handoffHeaders = result.outputContract["endpoint_handoff.csv"].columns;
    fs.writeFileSync(path.join(staging, "intake_decisions.csv"), csvText(decisionHeaders, result.decisions));
    fs.writeFileSync(path.join(staging, "replay_queue.jsonl"), `${result.queue.map(stableJson).join("\n")}\n`);
    fs.writeFileSync(path.join(staging, "endpoint_handoff.csv"), csvText(handoffHeaders, result.handoff));
    fs.rmSync(outputRoot, { recursive: true, force: true });
    fs.renameSync(staging, outputRoot);
  } catch (error) {
    fs.rmSync(staging, { recursive: true, force: true });
    throw error;
  }
}

const args = parseArgs(process.argv.slice(2));
const inputRoot = path.resolve(args.input);
const outputRoot = path.resolve(args.output);
try {
  const result = build(inputRoot);
  publish(outputRoot, result);
  process.stdout.write(`已排入${result.queue.length}条，拒绝${result.decisions.length - result.queue.length}条\n`);
} catch (error) {
  process.stderr.write(`${error.stack ?? error}\n`);
  process.exitCode = 1;
}
